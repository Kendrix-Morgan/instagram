//
//  te.swift
//  UIExercise_35
//
//  Created by Kendrix on 2024/07/02.
//

import SwiftUI
struct te:View {
    @State var selectedTag = 0
    
    var body: some View {
        VStack{
            
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all)
                
                TabView(selection: $selectedTag,
                        content:  {
                  
                        ContentView().tabItem {
                            Image(systemName: "house")
                            
                        }.tag(0)
                        
                        SearchView().tabItem {
                            Image(systemName: "magnifyingglass")
                            
                        }.tag(1)
                        
                        PlusView().tabItem {
                            Image(systemName: "plus.app")
                            
                        }.tag(2)
                        
                        ReelPage().tabItem {
                            
                            Image(systemName: "video.square")
                            
                        }.tag(3)
                        
                    
                }).imageScale(.large)
                    .frame(height: 875)

            }
        }
      
    }
}

#Preview {
    te()
}
