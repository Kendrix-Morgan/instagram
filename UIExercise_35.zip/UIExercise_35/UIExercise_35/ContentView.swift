//
//  ContentView.swift
//  UIExercise_35
//
//  Created by Kendrix on 2024/07/02.
//

//コードが多すぎるので色々なファイルに分けて、書きました。
//各ページの写真はスクロール可能です。
//リスト、スクロールビュー、写真の配列と写真データが主に使用されました
//上に　Instagram , heart icon とpaperplane iconをHStackの中で書いております
//ストーリーの背景色は、別の構造で色のグラデーションを使用して作成されました。
//ストーリ-が開げません。。
//同時にスクロールビューも使用できるように、すべてをリストにまとめました. インスタグラムストーリーの行は横スクロール可能
//以下のページのようなものも縦にスクロールすることもできます。この場合、最後の行は変更されません。
//ページの写真には　tabView　の機能を使用されました
//　写真の下にあるハートアイコンが使用可能となり、タッチすると赤い heart.fill に変わります。
//青色のテキストはリンク先 URL によってリンクされています。
//search pageの　「mappin.and.ellipse」は開けます。//search boxも記入でき
//一番下の行にあるiconは　navigation link で様々なリンクに接続されています。色々なアイコンを押していろいろ試してみてください!!!!!
//そうして　charleskeithofficial　のcommentに　LineLimit(2)を作成されまして、２行以上は (...)のように表示されます。
//yunPage のsystem iconの色は、palette の symbolRendering Mode を使用して作成しました。


// 1. scrollView                           // 11.TabView                                        // 21.clipShape(Circle())
// 2. LazyHGrid                            // 12.gradient (linear gradient)              // 22. cornerRadius()
// 3. LazyVStack                           // 13.imageScale                              // 23. opacity
// 4. PhotoArray                           // 14.bold                                    // 24. background()
// 5. Navigation View/navigation link      // 15.font                                    // 25. toggle()
// 6. List                                 // 16.section                                 // 26. button()
// 7. Hstack/VStack/ZStack                 // 17.offset                                  // 27. resizable()
// 8. Text                                 // 18.symbolRenderingMode(.palette)           // 28. aspectRatio()
// 9. Image                                // 19.foregroundColor                         // 29. frame()
// 10.Text                                 // 20.foregroundStyle                         // 30. Link (destionation :url)
                                                                                         // 31. LineLimit(2)
                                                     //32.picker


import SwiftUI

struct ContentView: View {
   
   let url = URL(string: "https://www.instagram.com/explore/tags/diorlebaume/?img_index=1")!
    let url2 = URL(string: "https://www.instagram.com/explore/tags/rougedior/?img_index=1")!
 
    let grids = [
         GridItem(.fixed(75),spacing: 10,alignment: .leading),
         GridItem(.fixed(20),alignment: .center)
        ]
    @State var selectedTag = 1
    @State var selectedTag1 = 1
    @State var isFavorited = false
    @State var isFavorited1 = false
    let gradientColors = [
                        Color(red: 133/255, green: 58/255, blue: 180/255), // Purple
                        Color(red: 193/255, green: 53/255, blue: 132/255), // Pink
                        Color(red: 253/255, green: 29/255, blue: 29/255),  // Red
                        Color(red: 245/255, green: 96/255, blue: 64/255),  // Orange
                        Color(red: 252/255, green: 175/255, blue: 69/255)  // Yellow
                    ]
 
    var body: some View {
        NavigationView{
            VStack {
                
                List{
                    Section{
                        VStack {
                            HStack(spacing :125) {
                                Text("Instagram")
                                    .foregroundStyle(.white)
                                    .font(.system(size: 35))
                                
                                HStack(spacing : 30){
                                 
                                 Image(systemName: "heart")
                                   
                                  Image(systemName: "paperplane")
                                    
                                }.foregroundColor(.white).imageScale(.large)
                             }//HStack For Title
                            
                            
                            ScrollView(.horizontal) {
                                LazyHGrid(rows: grids, spacing: 30){
                                    ForEach(photoArray) { item in
                                        Image(item.imageName)
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .clipShape(Circle())
                                            .background(storybackground())
                                        Text(item.title).font(.caption).foregroundColor(.white)
                                    }//forEach
                                }.padding()
                            }.frame(height: 100)
                            
                            ScrollView(.vertical){
                                LazyVStack(spacing:10) {
                                    HStack{
                                        
                                        NavigationLink(destination: EunWooStory()){
                                           
                                                ZStack {
                                                    LinearGradient(
                                                        gradient: Gradient(colors: gradientColors),
                                                        startPoint: .topLeading,
                                                        endPoint: .bottomTrailing)
                                                    .frame(width: 63,height: 63)
                                                    .cornerRadius(80)
                                                    
                                                    Image("IMG_3942")
                                                        .resizable()
                                                        .aspectRatio(contentMode: .fit)
                                                        .clipShape(Circle())
                                                        .frame(width: 56)
                                                }//ZStack
                                            
                                        }//navigation link
//                                        
                                        HStack {
                                            Text("eunwo.o_c")
                                                .foregroundColor(.white)
                                            Image(systemName: "checkmark.seal.fill")
                                                .foregroundColor(.blue)
                                                .imageScale(.small)
                                        }
                                    }.offset(x:-100)
                                        

                                      
                                    
                                    TabView(selection: $selectedTag) {
                                        Image("IMG_3960")
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .tag(1)
                                        Image("IMG_3961")
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .tag(2)
                                        Image("IMG_3959")
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .tag(3)
                                        
                                    }
                                    .tabViewStyle(PageTabViewStyle())
                                    .frame(width:400,height: 395)
                                    
                                    HStack(spacing:10){
                                        
                                        //heart button
                                        Button(action:{
                                            isFavorited.toggle()
                                        }){
                                            Image(systemName: isFavorited ? "heart.fill" : "heart")
                                                .foregroundColor(isFavorited ? .red : .white)
                                        }
                                        //heart button
                                        
                                        
                                        Text("4.8M")
                                        Image(systemName: "message")
                                            .foregroundColor(.white)
                                            .scaledToFit()
                                            .scaleEffect(x:-1,y: 1)
                                        Text("36.1K")
                                        Image(systemName: "paperplane")
                                            .foregroundColor(.white)
                                        Text("93.1K")
                                    } .imageScale(.large)
                                        .foregroundColor(.white)
                                        .font(.subheadline)
                                        .offset(x: -70)
                                        .bold()
                                    
                                    //comments and numbers of liked
                                    HStack {
                                        ZStack{
                                            Image("IMG_1978")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .clipShape(Circle())
                                                .frame(width: 23)
                                                .offset(x:15)
                                            Image("dior")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .clipShape(Circle())
                                                .frame(width: 25)
                                        }
                                        
                                        Text("\tLiked by")
                                        Text("nadio.o_c ").bold().offset(x:-5)
                                        Text("and").offset(x:-13)
                                        Text("others").bold().offset(x:-15)
                                        
                                    }  //liked by (HStack)
                                    .font(.system(size: 12))
                                    .foregroundColor(.white)
                                    .offset(x:-65)
                                    
                                    HStack {
                                        Text("eunwo.o_c").foregroundColor(.white).bold()
                                        Link(destination: url){
                                            Text("#DiorLeBaume")
                                            .foregroundColor(.blue)}
                                        
                                        Link(destination: url2){
                                            Text("#RougeDior")
                                            .foregroundColor(.blue)}
                                        
                                    }.font(.system(size: 12)).offset(x:-75,y: -6)
                                    
                                    
                                    Text("View all comments \nFebruary 8").foregroundStyle(.white).opacity(0.5).font(.system(size: 12)).offset(x: -133,y: -13)
                                    //comments and numbers of liked
                                    
                                    
                                    HStack{
                                        Image("C&K")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .clipShape(Circle())
                                            .frame(width: 55)
                                        Text("charleskeithofficial")
                                            .foregroundColor(.white)
                                        Image(systemName: "checkmark.seal.fill")
                                            .foregroundColor(.blue)
                                            .imageScale(.small)
                                    }.offset(x:-75)
                                    
                                    TabView(selection: $selectedTag1) {
                                        Image("IMG_3953")
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .tag(1)
                                        Image("IMG_3954")
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .tag(2)
                                        Image("IMG_3955")
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .tag(3)
                                        Image("IMG_3956")
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .tag(4)
                                    }
                                    .tabViewStyle(PageTabViewStyle())
                                    .frame(width:400,height: 395)
                                    
                                    //love , comments ... icons
                                    HStack(spacing:15){
                                        
                                        //heart button
                                        Button(action:{
                                            isFavorited1.toggle()
                                        }){
                                            Image(systemName: isFavorited1 ? "heart.fill" : "heart")
                                                .foregroundColor(isFavorited1 ? .red : .white)
                                        }
                                        //heart button

                                        Text("1,603")
                                        Image(systemName: "message")
                                            .foregroundColor(.white)
                                            .scaledToFit()
                                            .scaleEffect(x:-1,y: 1)
                                        Image(systemName: "paperplane")
                                            .foregroundColor(.white)
                                        Text("98")
                                    } .imageScale(.large)
                                        .foregroundColor(.white)
                                        .font(.subheadline)
                                        .offset(x: -85)
                                        .bold()
                                    //love , comments ... icons
                                    
                                    //comments and numbers of liked
                                    HStack {
                                        ZStack{
                                            Image("Image")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .clipShape(Circle())
                                                .frame(width: 23)
                                                .offset(x:15)
                                            Image("IMG_1978")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .clipShape(Circle())
                                                .frame(width: 25)
                                        }
                                        
                                        Text("\tLiked by")
                                        Text("camila_cabello").bold().offset(x:-5)
                                        Text("and").offset(x:-10)
                                        Text("others").bold().offset(x:-15)
                                        
                                    }  //liked by (HStack)
                                    .font(.system(size: 12))
                                    .foregroundColor(.white)
                                    .offset(x:-50)
                                    
                                    HStack {
                                        Text("charleskeithofficial Stay on trend with the chunky, Y2k- inspired Tattie platform mules. Take your pick from monochromatic hues \nand an eclecric dog-print version.").foregroundColor(.white).bold().lineLimit(2)
                                        
                                    }.font(.system(size: 12))
                                        .offset(x:3,y: -6)
                                    
                                    Text("View all comments \nJune 23").foregroundStyle(.white).opacity(0.5).font(.system(size: 12)).offset(x: -133,y: -13)
                                    //comments and numbers of liked
                                    
                                }//LazyVstack
                                
                            }
                        }//Vstack
                        .background(Color(red: 29/255, green: 29/255, blue: 29/255))
                        .frame(height: 1455)
                        .offset(y:15)
                        
                    }
                    .frame(height: 1400)
                    
                 }.listStyle(.plain)
                    .frame(width: UIScreen.main.bounds.width * 1.1,height: 710)
                
                HStack (spacing : 48){
                    Image(systemName: "house.fill")
                    
                    NavigationLink(destination:SearchView()){
                        Image(systemName: "magnifyingglass")
                    }
                    
                    
                    NavigationLink(destination:AddReel()){
                        Image(systemName: "plus.app")
                    }
                    
                    NavigationLink(destination:ReelPage()){
                        VStack(spacing:20){
                            Image("Pasted Graphic 1")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                            .frame(width: 25,height: 2)
                          Circle()
                              .frame(width: 5)
                              .foregroundColor(.black)
                        }.offset(y:15)
                    }
                    
                    NavigationLink(destination:yunpagenew()){
                        VStack{
                            Image("IMG_1978")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .clipShape(Circle())
                                .frame(width: 35)
                            Circle()
                                .frame(width: 5)
                                .foregroundColor(.red)
                        }.offset(y:10)
                    }//navigationLink
                    
                }//Hstack For Foot
                .foregroundColor(.white)
                .imageScale(.large)
                
            }
            .frame(width:  UIScreen.main.bounds.width ,height:UIScreen.main.bounds.height)
            .background(Color(red: 29/255, green: 29/255, blue: 29/255))
            .navigationBarBackButtonHidden(true)
        }
        
    
    }
    
}
//storyView をホームページの背景として表示しているときに、ホームページの背景色も変更します。


#Preview {
    ContentView()
}
