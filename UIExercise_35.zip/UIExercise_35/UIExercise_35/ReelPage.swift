//
//  reelPage.swift
//  Instagram
//
//  Created by Kendrix on 2024/07/01.
//

import SwiftUI
struct ReelPage:View {

    var body: some View {
        
        VStack {
            List{
                Section{
                    ZStack {
                        Image("ultraman")
                            .resizable()
                            .aspectRatio(contentMode: .fill)

                        
                        VStack(spacing:20){
                            Image(systemName: "heart")
                            Text("3.3M")
                            Image(systemName: "message")
                            Text("2M")
                            Image(systemName: "paperplane")
                            Text("1K")
                            Text("...")
                        }//Vstack
                        .foregroundStyle(.white)
                        .imageScale(.large)
                        .bold()
                        .offset(x:160,y:240)
                        
                        VStack {
                            HStack {
                                Image("netflix")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .clipShape(Circle())
                                    .frame(width: 57)
                                Text("Netflix").bold()
                                Image(systemName: "checkmark.seal.fill").foregroundStyle(.blue)
                                
                            }//Hstack
                        
                            Text("Ultraman 2024...").bold().background(.black.opacity(0.5))
                            
                        }.foregroundColor(.white).offset(x:-105,y:340)
                       
                    }
                }//section
                .frame(width: 400,height:896)
                .offset(y:-12)
                
                
                Section{
                    ZStack {
                        Image("flower")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 400,height:906)
                        
                        VStack(spacing:20){
                            Image(systemName: "heart")
                            Text("1K")
                            Image(systemName: "message")
                            Text("200")
                            Image(systemName: "paperplane")
                            Text("1K")
                            Text("...")
                        }//Vstack
                        .foregroundStyle(.white)
                        .imageScale(.large)
                        .bold()
                        .offset(x:160,y:240)
                        
                        VStack {
                            HStack {
                                Image("flower 1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .clipShape(Circle())
                                    .frame(width: 57)
                                Text("The Poem").bold()
                                Image(systemName: "checkmark.seal.fill").foregroundStyle(.blue)
                                
                            }//Hstack
                        
                            Text("Ultraman 2024...").bold()
                            
                        }.foregroundColor(.white).offset(x:-105,y:360)
                       
                    }.frame(width: 400,height:906)
                        
                }//section
                .offset(y:-30)
                
                Section{
                    ZStack {
                        Image("flash")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 400,height:906)
                        
                        VStack(spacing:20){
                            Image(systemName: "heart")
                            Text("7M")
                            Image(systemName: "message")
                            Text("2M")
                            Image(systemName: "paperplane")
                            Text("16K")
                            Text("...")
                        }//Vstack
                        .foregroundStyle(.white)
                        .imageScale(.large)
                        .bold()
                        .offset(x:160,y:240)
                        
                        VStack {
                            HStack {
                                Image("DC")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .clipShape(Circle())
                                    .frame(width: 57)
                                Text("DC").bold()
                                Image(systemName: "checkmark.seal.fill").foregroundStyle(.blue)
                                
                            }//Hstack
                        
                            Text("Ultraman 2024...").bold().offset(x:20)
                            
                        }.foregroundColor(.white).offset(x:-125,y:360)
                       
                    }.frame(width: 400,height:906)
                        .offset(y:-50)
                }
            }
            .listStyle(.plain)
            .offset(y:-15)

        .frame(width: UIScreen.main.bounds.width,height: UIScreen.main.bounds.height)
        }.background(Color(red: 29/255, green: 29/255, blue: 29/255))
           
        
    }
    
    
}
#Preview {
    ReelPage()
}
