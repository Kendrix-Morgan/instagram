//
//  storyView.swift
//  Instagram
//
//  Created by Kendrix on 2024/06/29.
//

import SwiftUI
struct storyView:View {
    let grids = [
         GridItem(.fixed(75),spacing: 10,alignment: .leading),
         GridItem(.fixed(20),alignment: .center)
        ]
    
    var body: some View {
        ScrollView(.horizontal) {
            LazyHGrid(rows: grids, spacing: 30){
                ForEach(photoArray) { item in
                    Image(item.imageName)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .clipShape(Circle())
                        .background(storybackground())
                    Text(item.title).font(.caption).foregroundColor(.white)
                }//forEach
            }.padding()
        }.frame(height: 100)
            .offset(y:-259)
    
    }//body
}
//下に設定したPhotoDataとbackground color,その 2 つを同じページにまとめます。

#Preview {
    storyView()
}
