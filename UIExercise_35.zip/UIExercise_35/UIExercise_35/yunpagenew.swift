//
//  yunpagenew.swift
//  UIExercise_35
//
//  Created by Kendrix on 2024/07/10.
//

import SwiftUI

struct yunpagenew: View {
    let gradientColors = [
                        Color(red: 133/255, green: 58/255, blue: 180/255), // Purple
                        Color(red: 193/255, green: 53/255, blue: 132/255), // Pink
                        Color(red: 253/255, green: 29/255, blue: 29/255),  // Red
                        Color(red: 245/255, green: 96/255, blue: 64/255),  // Orange
                        Color(red: 252/255, green: 175/255, blue: 69/255)  // Yellow
                    ]
    let grids3 = [
        GridItem(.fixed(75),spacing: 10,alignment: .center),
        GridItem(.fixed(20),alignment: .leading)
    ]
    let grids4 = Array(repeating: GridItem(.fixed(100)), count: 3)
    
    var body: some View {
        
        
        VStack {
            ScrollView(.vertical){
                LazyVStack(spacing:10){
                    
                    HStack(spacing:105){
                        Text("nadio.o_y").font(.system(size: 30))
                            .offset(x:-28)
                        
                        HStack(spacing:30) {
                            Image(systemName: "plus.square")
                            Image(systemName: "line.horizontal.3")
                        }.imageScale(.large)
                    }.foregroundColor(.white).bold()
                    
                    
                    HStack {
                        //profile picture
                        
                        ZStack {
                            LinearGradient(
                                gradient: Gradient(colors: gradientColors),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing)
                            .frame(width: 102,height: 102)
                            .cornerRadius(80)
                            
                            Image("IMG_1978")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .clipShape(Circle())
                                .frame(width: 107)
                            
                            Image(systemName: "plus.circle.fill")
                                .symbolRenderingMode(.palette)
                                .foregroundStyle(Color.white,Color.blue)
                                .imageScale(.large)
                                .offset(x: 40,y: 35)
                            
                        }//ZStack
                        .offset(y:20)
                        
                        //profile picture
                        
                        VStack {
                            HStack(spacing:60) {
                                Text("21")
                                Text("2M")
                                Text("62")
                            }
                            HStack(spacing:30){
                                Text("post")
                                Text("followers")
                                Text("following")
                            }.offset(x:10)
                        }.foregroundColor(.white).font(.subheadline).offset(x:20,y: 20)
                        
                    }//HStack
                    .offset(x:-28)
                    
                    //profile name
                    VStack{
                        Text("Kendrix").bold()
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 23.0)
                                .frame(width: 120,height: 40)
                                .foregroundColor(Color("light-black1"))
                            Text("@ nadio.o_y")
                        }//Zstack forRoundedRectangle
                        .offset(x: 26)
                        
                        HStack {
                            Image(systemName:"mappin.and.ellipse")
                                .symbolRenderingMode(.palette)
                                .foregroundStyle(Color.red,Color.white)
                                .imageScale(.large)
                            Text("Tokyo")
                        }//Hstack Tokyo Map
                        .offset(x: 9)
                    }//VStack
                    .foregroundColor(.white).offset(x: -150,y: 15)
                    //profile name
                    
                    HStack{
                        ZStack{
                            RoundedRectangle(cornerRadius: 13.0)
                                .frame(width: 150,height: 50)
                                .foregroundColor(Color(red: 38/255, green: 38/255, blue: 38/255))
                            Text("Edit profile")
                        }//Zstack forRoundedRectangle
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 13.0)
                                .frame(width: 150,height: 50)
                                .foregroundColor(Color(red: 38/255, green: 38/255, blue: 38/255))
                            Text("Share profile")
                        }//Zstack forRoundedRectangle
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 13.0)
                                .frame(width: 50,height: 50)
                                .foregroundColor(Color(red: 38/255, green: 38/255, blue: 38/255))
                            Text("+").offset(x:-10,y: -3)
                            Image(systemName: "person").imageScale(.large)
                            
                        }//Zstack forRoundedRectangle
                        
                    }.offset(x:-7,y: 18)
                        .foregroundColor(.white).font(.subheadline)
                    
                    HStack(spacing:120) {
                        Image(systemName: "squareshape.split.3x3")
                        
                        Image("Pasted Graphic 1")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 20,height: 25)
                        
                        Image(systemName: "person.crop.square")
                        
                    }.imageScale(.large)
                        .foregroundStyle(Color.white)
                        .offset(x:-10,y:30)
                    
                    LazyVGrid(columns: grids4, spacing: 15){
                        
                        ForEach(photoArray4) { item in
                            
                            Image(item.imageName)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                .frame(width: 106,height: 150)
                            
                        }//forEach
                        
                    }.offset(x:-10,y:50)
                    
                    
                    
                }//LazyVStack
            }//scroll view
            
            .offset(x:9,y:80)
                
        }//outer vstack
        .frame(width: UIScreen.main.bounds.width,height: 870)
        .background(Color(red: 29/255, green: 29/255, blue: 29/255))
        
    }
}

#Preview {
    yunpagenew()
}
