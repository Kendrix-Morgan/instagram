//
//  AddReel.swift
//  UIExercise_35
//
//  Created by Kendrix on 2025/03/13.
//


import SwiftUI

struct AddReel:View {
    @Environment(\.dismiss) var dismiss
    @State private var choice = 0
    @State private var showAlbumList = false
       
    let albumOptions = [
        ("Recents", ""),
        ("Recents", "photo.on.rectangle.angled"),
        ("Video", "play.circle"),
        ("Favorites", "heart"),
        ("All Albums", "square.grid.2x2")
    ]
       let grids3 = [
           GridItem(.fixed(75), spacing: 10, alignment: .center),
           GridItem(.fixed(20), alignment: .leading)
       ]
       
       let grids4 = Array(repeating: GridItem(.fixed(100)), count: 3)
       
    var body: some View {
        NavigationView {
            ZStack {
                VStack {
                    
                    HStack(spacing:120) {
                        backButtonOverlay()
                        Text("New Post")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 20))
                            .foregroundColor(.gray)
                    }.padding(.horizontal)
                    
                    ScrollView(.vertical, showsIndicators: false) {
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            LazyHGrid(rows: grids3, spacing: 90){
                                ForEach(photoArray3) { item in
                                    Image(item.imageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: 40,height: 10)
                                        .background(square())
                                    Text(item.title).font(.caption).foregroundColor(.white)
                                        .offset(y:-20)
                                }//forEach
                                
                            }//LazyHGrid
                            .offset(x:50)
                        }.frame(height: 170)
                            .opacity(0.8)
                        
                        // Album Selector Button
                        ZStack {
                            Button(action: {
                                withAnimation {
                                    showAlbumList.toggle()
                                }
                            }) {
                                HStack {
                                    Text(albumOptions[choice].0)
                                    Image(systemName: "chevron.down")
                                        .rotationEffect(.degrees(showAlbumList ? 180 : 0))
                                    Spacer()
                                }
                                .foregroundColor(.white)
                                .font(.system(size: 16, weight: .medium))
                                .padding(.leading,10)
                                
                            }
                            
                            
                        }
                        
                        ScrollView(.vertical) {
                            
                            LazyVGrid(columns: grids4, spacing: 15){
                                
                                ForEach(photoArray4) { item in
                                    
                                    Image(item.imageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                        .frame(width: 106,height: 150)
                                    
                                }//forEach
                                
                            }
                            
                        }.frame(height: 570)
                        
                    }//outer scroll view
                    
                }//inner vstack
                
                // Conditional Picker
                if showAlbumList {
                    ZStack {
                        List {
                            ForEach(albumOptions.indices, id: \.self) { index in
                                Button(action: {
                                    choice = index
                                    showAlbumList = false  // Hide the list after selection
                                }) {
                                    HStack {
                                        Text(albumOptions[index].0)
                                            .foregroundColor(.black)
                                        Spacer()
                                        if !albumOptions[index].1.isEmpty {
                                            Image(systemName: albumOptions[index].1)
                                                .foregroundColor(.black)
                                        }
                                    }
                                }
                                .listRowBackground(Color.white) // Keeps background consistent
                            }
                        }
                        .listStyle(.plain)
                        
                    }.frame(width:250,height: 230)
                        .background(.white)
                        .cornerRadius(10)
                        .padding(.bottom,50)
                        .transition(.opacity)
                }
                
            }//outer ZStack
            .padding(.top,50)
            .frame(width: UIScreen.main.bounds.width,height: UIScreen.main.bounds.height)
            .background(Color(red: 29/255, green: 29/255, blue: 29/255))
           
        } .navigationBarBackButtonHidden(true)
       
    }
    private func backButtonOverlay() -> some View {
        HStack {
            Button(action: {
                dismiss() // Dismiss the view when tapped
            }) {
                HStack {
                    Text("X")
                        .foregroundColor(.white).font(.system(size: 20))
                }
            }
        }
    
    }

}

struct square:View {
    var body: some View {
        RoundedRectangle(cornerRadius: 15 )
            .frame(width: 120,height: 110)
            .foregroundColor(Color(red: 38/255, green: 38/255, blue: 38/255))
            .padding()
    }
}

#Preview {
    AddReel()
}
