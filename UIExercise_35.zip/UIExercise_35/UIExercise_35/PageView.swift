//
//  PageView.swift
//  Instagram
//
//  Created by Kendrix on 2024/06/29.
//

import SwiftUI
struct Pageview: View {
    @State var selectedTag = 1
    let gradientColors = [
                        Color(red: 133/255, green: 58/255, blue: 180/255), // Purple
                        Color(red: 193/255, green: 53/255, blue: 132/255), // Pink
                        Color(red: 253/255, green: 29/255, blue: 29/255),  // Red
                        Color(red: 245/255, green: 96/255, blue: 64/255),  // Orange
                        Color(red: 252/255, green: 175/255, blue: 69/255)  // Yellow
                    ]
    
    var body: some View {
        
        VStack {
            ScrollView(.vertical){
                LazyVStack(spacing:10) {
                    ZStack {
                        LinearGradient(
                            gradient: Gradient(colors: gradientColors),
                                      startPoint: .topLeading,
                                      endPoint: .bottomTrailing)
                        .frame(width: 62,height: 62)
                        .cornerRadius(80)
                        .offset(x:-162)

                        HStack{
                           Image("IMG_3942")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .clipShape(Circle())
                                .frame(width: 55)
                            Text("eunwo.o_c")
                             .foregroundColor(.white)
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.blue)
                                .imageScale(.small)
                        }.offset(x:-105)
                    }//Zstack
                    
                    
                    TabView(selection: $selectedTag) {
                        Image("IMG_3960")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .tag(1)
                        Image("IMG_3961")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .tag(2)
                        Image("IMG_3959")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .tag(3)
                       
                    }
                    .tabViewStyle(PageTabViewStyle())
                    .frame(width:400,height: 395)
                    
                    HStack{
                        Image("C&K logo")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .clipShape(Circle())
                            .frame(width: 55)
                        Text("charleskeithofficial")
                            .foregroundColor(.white)
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.blue)
                            .imageScale(.small)
                    }.offset(x:-75)
                    
                    TabView(selection: $selectedTag) {
                        Image("IMG_3953")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .tag(1)
                        Image("IMG_3954")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .tag(2)
                        Image("IMG_3955")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .tag(3)
                        Image("IMG_3956")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .tag(4)
                    }
                    .tabViewStyle(PageTabViewStyle())
                    .frame(width:400,height: 395)
                }//LazyVstack
                
            }
        }//Vstack
        .background(Color(red: 29/255, green: 29/255, blue: 29/255))
        .frame(width: UIScreen.main.bounds.width,height: UIScreen.main.bounds.height)
        .ignoresSafeArea()
    }
}



