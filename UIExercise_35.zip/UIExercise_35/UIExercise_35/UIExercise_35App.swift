//
//  UIExercise_35App.swift
//  UIExercise_35
//
//  Created by Kendrix on 2024/07/02.
//

import SwiftUI

@main
struct UIExercise_35App: App {
   
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
