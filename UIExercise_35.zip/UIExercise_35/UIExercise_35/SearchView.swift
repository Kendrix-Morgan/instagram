//
//  SearchView.swift
//  Instagram
//
//  Created by Kendrix on 2024/06/30.
//

import SwiftUI

struct SearchView: View {
    @State private var searchText = ""
    let grids2 = Array(repeating: GridItem(.fixed(100)), count: 3)
    let googleMapsURL = URL(string: "https://maps.google.com/")!
    
    var body: some View {
                    VStack {
                
                HStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: 15.0)
                            .frame(width: 320,height: 43)
                            .foregroundColor(Color("light black").opacity(0.7))
                        
                        HStack {
                            Image(systemName: "magnifyingglass")
                                .imageScale(.medium)
                            
                            TextField("Search",text: $searchText)
                                .font(.system(size: 20))
                                .foregroundColor(.white)
                                .padding(.vertical,10)
                                .padding(.horizontal,20)
                         }.foregroundColor(.white)
                            .offset(x:19).opacity(0.6)
                    }
                       
                        Button(action: {
                                        if UIApplication.shared.canOpenURL(self.googleMapsURL) {
                                            UIApplication.shared.open(self.googleMapsURL, options: [:], completionHandler: nil)
                                        }
                                    }) {
                                        Image(systemName: "mappin.and.ellipse")
                                            .resizable()
                                            .frame(width: 30, height: 40)
                                            .foregroundStyle(.white)
                                        // Adjust size as needed
                                    }
                   }.padding()
                
                ScrollView(.vertical) {
                    LazyVGrid(columns: grids2, spacing: 20){
                        ForEach(photoArray2) { item in
                            Image(item.imageName)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                .frame(width: 106)
                            
                        }//forEach
                    }.frame(width: 400,height: 710)
                    
                    
                }
            }//
            .background(Color(red: 29/255, green: 29/255, blue: 29/255))
        
    }
}
#Preview {
    SearchView()
}
