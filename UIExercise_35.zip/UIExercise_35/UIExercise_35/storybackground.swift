//
//  storybackground.swift
//  Instagram
//
//  Created by Kendrix on 2024/06/29.
//

import SwiftUI


struct storybackground:View {
    let gradientColors = [
                        Color(red: 133/255, green: 58/255, blue: 180/255), // Purple
                        Color(red: 193/255, green: 53/255, blue: 132/255), // Pink
                        Color(red: 253/255, green: 29/255, blue: 29/255),  // Red
                        Color(red: 245/255, green: 96/255, blue: 64/255),  // Orange
                        Color(red: 252/255, green: 175/255, blue: 69/255)  // Yellow
                    ]
    
    var body: some View {
    LinearGradient(
        gradient: Gradient(colors: gradientColors),
                  startPoint: .topLeading,
                  endPoint: .bottomTrailing)
    .frame(width: 82,height: 82)
    .cornerRadius(80)
    }
}
//imageのBackground Colorのためcolor gradientを設定しました
//imageよりsizeをちょっと大きくして、後丸くします。
