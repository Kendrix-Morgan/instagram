//
//  EunWooStory.swift
//  UIExercise_35
//
//  Created by Kendrix on 2024/07/08.
//

import SwiftUI

struct EunWooStory: View {
    @State var istouch = false
   
    var body: some View {
        VStack {
            VStack {
                HStack(spacing:10){
                    Image("IMG_3942")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .clipShape(Circle())
                        .frame(width: 56)
                    Text("eunwo.o_c")
                    Image(systemName: "checkmark.seal.fill")
                       .imageScale(.small)
                    Text("2m").opacity(0.7)
                    
                }.offset(x:-70).bold()
                .foregroundColor(.white)
                
               Image("eunwoostory")
                        .resizable()
                        .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                        .frame(width: 380,height: 200)
                        .offset(y:190)
             
                
            }
            .offset(y:-200)
        }//outer Vstack
        
        .frame(maxWidth: .infinity,maxHeight: .infinity)
        .ignoresSafeArea()
        .background(Color(red: 73/255, green: 108/255, blue: 100/255,opacity: 0.5))
        
    }
}

#Preview {
    EunWooStory()
}
