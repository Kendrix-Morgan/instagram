//
//  PhotoData.swift
//  Instagram
//
//  Created by Kendrix on 2024/06/29.
//

import Foundation

struct PhotoData:Identifiable{
    var id = UUID()
    var imageName:String
    var title:String
}
var photoArray = [
      PhotoData(imageName: "IMG_1978", title: "Your story"),
      PhotoData(imageName: "IMG_3949", title: "sai_chenn"),
      PhotoData(imageName: "IMG_3942", title: "eunwo.o_c"),
      PhotoData(imageName: "Image", title: "camila_cabello"),
      PhotoData(imageName: "IMG_3943", title: "dntlrdl"),
      PhotoData(imageName: "IMG_3944", title: "zara"),
    ]
var photoArray2 = [
      PhotoData(imageName: "chanel1", title: "chanel"),
      PhotoData(imageName: "diorperfume", title: "perfume"),
      PhotoData(imageName: "chanel", title: "chanel"),
      PhotoData(imageName: "3", title: "aquaman"),
      PhotoData(imageName: "2", title: "zootopia"),
      PhotoData(imageName: "4", title: "anola"),
      PhotoData(imageName: "Untitled", title: "zootopia"),
      PhotoData(imageName: "galaxy", title: "zootopia"),
      PhotoData(imageName: "1", title: "zootopia"),
      PhotoData(imageName: "merlin", title: "the wizard"),
      PhotoData(imageName: "wish", title: "wish dragon"),
      PhotoData(imageName: "harry", title: "harry")
      
    ]
var photoArray4 = [
      PhotoData(imageName: "IMG_3986", title: "Your music"),
      PhotoData(imageName: "flower", title: "flower"),
      PhotoData(imageName: "lunch", title: "lunch"),
      PhotoData(imageName: "inside", title: "cartoon"),
      PhotoData(imageName: "selena", title: "selena"),
      PhotoData(imageName: "tokyo", title: "tokyo"),
      PhotoData(imageName: "taylor1", title: "taylor"),
      PhotoData(imageName: "IMG_3888", title: "camilacouple"),
      PhotoData(imageName: "tower", title: "tower"),
      PhotoData(imageName: "chanel1", title: "chanel"),
      PhotoData(imageName: "diorperfume", title: "perfume"),
      PhotoData(imageName: "chanel", title: "chanel"),
      PhotoData(imageName: "3", title: "aquaman"),
      PhotoData(imageName: "2", title: "zootopia"),
      PhotoData(imageName: "4", title: "anola"),
      PhotoData(imageName: "Untitled", title: "zootopia"),
      PhotoData(imageName: "galaxy", title: "zootopia"),
      PhotoData(imageName: "1", title: "zootopia"),
      PhotoData(imageName: "merlin", title: "the wizard"),
      PhotoData(imageName: "wish", title: "wish dragon"),
      PhotoData(imageName: "harry", title: "harry")
    ]

var photoArray3 = [
    PhotoData(imageName: "camera", title: "Camera"),
    PhotoData(imageName: "GIF", title: "Clip hub"),
    PhotoData(imageName: "Templates", title: "Templates"),
    PhotoData(imageName: "made", title: "Made for you")
   
]
var photoArray5 = [
    PhotoData(imageName: "camera", title: "Camera"),
    PhotoData(imageName: "GIF", title: "Drafts")
]
//(Chapter 4-4)PhotoData.swift には写真データの内容を示す構造体 PhotoDataの定義と変数photoArrayに6枚分の写真データを配列にするコードが書いてあります
